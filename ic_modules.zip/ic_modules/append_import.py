from ic_modules import ic_01
from ic_modules import ic_02
from ic_modules import icyh


ic_01.show_1()
ic_02.show_2()
icyh.icyh()