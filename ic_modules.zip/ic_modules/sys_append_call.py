import os
import sys
if __name__ == '__main__':
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    print(BASE_DIR)
    sys.path.append(BASE_DIR)


#sys.path.append("D:\IC_MODULES\IC_modules")

import ic_01
import ic_02
import icyh


ic_01.show_1()
ic_02.show_2()
icyh.icyh()