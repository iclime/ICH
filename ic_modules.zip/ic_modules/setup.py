from distutils.core import setup
setup(name="ic",version="0.0.1",description="This is a module made by LimeQWQ",author="LimeQWQ",py_modules=["ic_modules.ic_01","ic_modules.ic_02","ic_modules.icyh"])
