def show_1():
    print("This is ic01.show_1() By: LimeQWQ")