def show_2():
    print("This is ic02.show_2() By: LimeQWQ")